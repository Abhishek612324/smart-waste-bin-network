
# Simple nearest-neighbor route planner for collection trucks
# Input: list of bins as (id, lat, lon, fill_percent)
# Output: ordered list of bin ids to visit (starting from depot)

import math

def haversine(a, b):
    # a and b are (lat, lon) in degrees
    R = 6371.0
    lat1, lon1 = math.radians(a[0]), math.radians(a[1])
    lat2, lon2 = math.radians(b[0]), math.radians(b[1])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    aa = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    c = 2*math.atan2(math.sqrt(aa), math.sqrt(1-aa))
    return R * c

def nearest_neighbor_route(depot, bins, threshold=80):
    # depot: (lat, lon)
    # bins: list of dicts with keys 'id','lat','lon','fill'
    # select bins above threshold first
    targets = [b for b in bins if b.get('fill',0) >= threshold]
    if not targets:
        return []
    route = []
    current = depot
    remaining = targets.copy()
    while remaining:
        nearest = min(remaining, key=lambda x: haversine((x['lat'], x['lon']), current))
        route.append(nearest['id'])
        current = (nearest['lat'], nearest['lon'])
        remaining.remove(nearest)
    return route

if __name__ == '__main__':
    depot = (17.412, 78.401) # example coordinates (Hyderabad)
    bins = [
        {'id':'B1','lat':17.413,'lon':78.402,'fill':85},
        {'id':'B2','lat':17.414,'lon':78.405,'fill':60},
        {'id':'B3','lat':17.410,'lon':78.400,'fill':92},
    ]
    print("Planned route:", nearest_neighbor_route(depot, bins, threshold=80))
