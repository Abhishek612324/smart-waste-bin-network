
# Smart Waste Bin Network - Reference Repository

Author: Abhishek Dobbala
Course: B.Tech - ECE, 3rd Year
College: J.B. Institute of Engineering and Technology, Hyderabad

This repository contains reference code and documentation to support the Smart Waste Bin Network project (Virtual IoT Design Challenge).
It includes:
- ESP32 firmware to read ultrasonic sensor and publish MQTT messages
- Simple route optimization script (nearest-neighbor heuristic)
- Documentation and slides for submission

**How to use**
1. Edit `src/esp32_mqtt.ino` with your Wi-Fi and MQTT broker credentials.
2. Upload the sketch to an ESP32 using Arduino IDE or PlatformIO.
3. Run the `route_optimization.py` script to produce an example route from a list of bin coordinates.

---
